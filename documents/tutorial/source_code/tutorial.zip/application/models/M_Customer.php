<?php

class M_Customer extends CI_Model{

	private $table = 'tbl_customer';

	public function __construct()
    {
        parent::__construct();
    }

	public function insert($data){
        $this->db->insert($this->table,$data);
    }

    public function getAllData(){
        $query =  $this->db->get($this->table);
        return $query->result();
    }

    public function update($data,$criteria){
    	$this->db->update($this->table,$data,$criteria);
    }

	public function getDataByCriteria($criteria,$limit=""){
    	$query = $this->db->get_where($this->table,$criteria);
    	return $query->result();
    }

	public function delete($criteria){
		$this->db->delete($this->table,$criteria);
	}
	
    public function __destruct() {
		$this->db->close();
   	}

}
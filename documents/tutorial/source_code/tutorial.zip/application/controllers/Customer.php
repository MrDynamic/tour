<?php

Class Customer extends CI_Controller{


	public function __construct()
    {
        parent::__construct();
        $this->load->model(array('M_Customer'=>'cust'));
    }

	public function index(){
		$listData["list_data"] = $this->cust->getAllData();
		$html['yeild'] = $this->load->view('view_customer',$listData,true);
		$this->load->view('layout.php',$html);
	}


	public function create(){
		$html['yeild'] = $this->load->view('create_customer','',true);
		$this->load->view('layout.php',$html);
	}

	public function save(){
		unset($this->input->post()['action']);
		$this->cust->insert($this->input->post());
		redirect('customer');
	}

	public function edit(){
		$customerId = $this->uri->segment(3);
		if($customerId){
			$data = $this->cust->getDataByCriteria(array('custId'=>$customerId));
			$editData['editData'] = $data[0];
			$editData['action'] = 'edit';
			$html['yeild'] = $this->load->view('create_customer',$editData,true);
			$this->load->view('layout.php',$html);
			
		}
	}

	public function update(){

		$customerId = $this->uri->segment(3);
		$this->cust->update($this->input->post(),array('custId'=>$customerId));
		redirect('customer');
	}

	public function delete(){
		$this->cust->delete(array('custId'=>$this->uri->segment(3)));
		redirect('customer');
	}

	


}
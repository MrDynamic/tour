<div class="adv-table">
      <div class="space15"></div>
      <table class="table table-striped table-hover table-bordered" id="editable-sample">
          <thead>
          <tr>
              <th>No.</th>
              <th>Firstname</th>
              <th>Lastname</th>
              <th>Email</th>
              <th>Edit</th>
              <th>Delete</th>
          </tr>
          </thead>
          <tbody>
          <?php
              if(!isset($list_data)|| empty($list_data)) { 
                  echo "<tr class='txt-not-found'><td colspan=6>Data Not Found</td></tr>";
              } else{
                $i=1;
                foreach ($list_data as $rows){
                  echo "<tr class=''>";
                  echo "<td>$i</td>";
                  echo "<td>$rows->firstname</td>";
                  echo "<td>$rows->lastname</td>";
                  echo "<td>$rows->email</td>";
                    echo "<td>";
                    echo anchor("customer/edit/$rows->custId", 'Edit');
                    echo "</td>";
                    echo "<td>";
                    echo anchor("customer/delete/$rows->custId", 'Delete');
                    echo "</td>";
                  echo "</tr>";
                  $i++;
                }
              }
          ?>
          </tbody>
      </table>
  </div>
</div>
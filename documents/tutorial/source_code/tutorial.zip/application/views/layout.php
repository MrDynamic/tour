<!DOCTYPE html>
<html>
<head>
  <title>Codeigniter Tutorial</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <style>
      .txt-not-found{
        text-align: center;
        color: #585858;
      }
  </style>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <?php
        echo anchor('customer','Codeigniter Tutorial',array('class'=>'navbar-brand'));
      ?>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
       <li>
          <?php 
            echo anchor('customer/create', 'Create Customer');
          ?>
       </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div class="container">
	 <div class="row">
		 <div class="col-md-offset-3 col-md-6">
       
            <!-- Content -->
    		 	  <?php
              (isset($yeild) && !empty($yeild))? print $yeild:'';
            ?>      
       </div>
	 </div>
 </div>
<script src="http://code.jquery.com/jquery-2.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</body>
</html>

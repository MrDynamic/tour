	<div class="panel panel-default">
	  <div class="panel-heading">Create Customer</div>
	  <div class="panel-body">
	    <?php
			$firstname = array('name'=>'firstname','id'=>'firstname','class'=>'form-control'
				,'required'=>'');
			$lastname= array('name'=>'lastname','id'=>'lastname','class'=>'form-control','required'=>'');
			$email = array('type'=>'email','name'=>'email','id'=>'email','class'=>'form-control');
	    	
	    	if(isset($action) && $action == 'edit'){
	    		$action = "customer/update/$editData->custId";
	    		$firstname['value'] = set_value('firstname',$editData->firstname);
	    		$lastname['value'] = set_value('lastname',$editData->lastname);
	    		$email['value'] = set_value('email',$editData->email);
	    		
	    	}else{
	    		$action = 'customer/save';
	    	}

	    	echo form_open($action,array('id'=>'formCustomer','role'=>'form'));
			echo '<div class="form-group">';
			echo form_label('First Name','firstname');
			echo form_input($firstname);
			echo '</div>';
			echo '<div class="form-group">';
			echo form_label('Lastname ','lastname');
			echo form_input($lastname);
			echo '</div>';
			echo '<div class="form-group">';
			echo form_label('Email ','email');
			echo form_input($email);
			echo '</div>';
			echo form_button(array('type'=>'submit','class'=>'btn btn-info','content'=>'Save'));
			echo form_button(array('type'=>'reset','class'=>'btn btn-info','content'=>'Cancel'));
			echo form_close();

		
	?>
	  </div>
	</div>

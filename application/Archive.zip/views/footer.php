<footer id="footer">
        <div class="copyright sep-top-xs sep-bottom-xs">
          <div class="container">
            <div class="row">
              <div class="col-md-12"><small>Copyright 2016 © Ocharos tour. All rights reserved.</small></div>
            </div>
          </div>
        </div>
      </footer>
<div class="col-md-3 col-md-pull-9 sep-top-2x">
  <h5 class="widget-title upper sep-bottom-xs">รายการ</h5>
  <ul class="widget widget-cat">
    <li class="cat-item"><a href="<?=site_url('user/editUser');?>" class="upper">ข้อมูลส่วนตัว</a></li>
    <li class="cat-item"><a href="<?=site_url('user/changePasswordPage')?>" class="upper">เปลี่ยนรหัสผ่าน</a></li>
    <li class="cat-item"><a href="<?=site_url('user/orderListPage');?>" class="upper">รายการสั่งซื้อ</li>
    <li class="cat-item"><a href="#" class="upper">จัดแพคเก็จ</a></li>
  </ul>
</div>
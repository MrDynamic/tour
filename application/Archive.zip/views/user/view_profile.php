<div class="accordion-item panel">
<h5 class="accordion-heading">แก้ไขข้อมูลส่วนตัว</h5>
<div class="sep-top-xs">
  <ul class="social-icon pull-right">
    <li><a href="#"><i class="fa fa-twitter fa-lg"></i></a></li>
    <li><a href="#"><i class="fa fa-facebook-square fa-lg"></i></a></li>
    <li><a href="#"><i class="fa fa-pinterest fa-lg"></i></a></li>
  </ul>

  <ul class="social-icon">
    <li><a href="#"><i class="fa fa-heart"></i><small>&nbsp;1500</small></a></li>
    <li><a href="#"><i class="fa fa-eye"></i><small>&nbsp;1500</small></a></li>
    <li class="maxi"><a href="#"><i class="fa fa-comments"></i><small>&nbsp;1500 Comments</small></a></li>
  </ul>
</div>
<div class="accordion-body">
  <p class="lead">
    Curabitur pellentesque neque eget diam posuere porta. Quisque
    ut nulla at nunc vehicula lacinia. Proin adipiscing porta
    tellus, ut feugiat nibh. Lorem ipsum nulla amos eget purus
    vel mauris tincidunt tincidunt nibh tortor. Nunc faucibus
    pellentesque facilisis. Interdum et malesuada fames ac ante
    ipsum primis in faucibus.
  </p>
</div>
</div>
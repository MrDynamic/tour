<div class="col-md-4 sep-top-md icon-gradient">
  <div class="icon-box icon-horizontal icon-md">
    <div class="icon-content img-circle">
    	<i class="fa fa-group"></i>
    </div>
    <div class="icon-box-content">
      <h5 class="upper"><a href="<?=site_url('user/editUser');?>">ข้อมูลส่วนตัว</a></h5>
    </div>
  </div>
</div>
<div class="col-md-4 sep-top-md icon-gradient">
  <div class="icon-box icon-horizontal icon-md">
    <div class="icon-content img-circle"><i class="fa fa-shopping-cart"></i></div>
    <div class="icon-box-content">
      <h5 class="upper">
      	<a href="<?=site_url('user/orderListPage');?>">รายการสั่งซื้อ</a>
      </h5>
    </div>
  </div>
</div>
<div class="col-md-4 sep-top-md icon-gradient">
  <div class="icon-box icon-horizontal icon-md">
    <div class="icon-content img-circle"><i class="fa fa-table"></i></div>
    <div class="icon-box-content">
      <h5 class="upper">
      	<a href="#">จัดแพคเก็จ</a>
      </h5>
    </div>
  </div>
</div>

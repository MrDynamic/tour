<section id="package" class="sep-top-2x sep-bottom-md sep-top-md">
    <div class="container">
      <div class="row">
        <div class="col-md-3 sep-bottom-lg"><a href="shop-product.html" class="product-image outline-outward"><img src="resources/img/products/4.jpg" alt="Only You" class="img-responsive"></a>
          <div class="product-title"><span class="upper">woman</span>
            <p>Only You</p>
          </div>
          <div class="product-detail">
            <div class="pull-right price-shop text-right">
              <ins>$19.00</ins>
            </div>
          </div>
        </div>
        
<!--         <div class="col-md-3 sep-bottom-lg"><a href="shop-product.html" class="product-image outline-outward"><img src="resources/img/products/2.jpg" alt="Osaka Men's Shirt" class="img-responsive"></a> -->
<!--           <div class="product-title"><span class="upper">man</span> -->
<!--             <p>Osaka Men's Shirt</p> -->
<!--           </div> -->
<!--           <div class="product-detail"> -->
<!--             <div class="pull-right price-shop text-right"> -->
<!--               <del>$18.50</del><ins>$14.00</ins> -->
<!--             </div> -->
<!--             <div class="rate"> -->
<!--               <input type="number" name="" value="4" data-clearable="remove" data-max="5" data-min="1" data-icon-lib="fa" data-active-icon="fa-star" data-inactive-icon="fa-star-o" data-clearable-icon="fa-times" class="rating"> -->
<!--             </div><a href="#">6 customer reviews</a> -->
<!--           </div> -->
<!--         </div> -->
<!--         <div class="col-md-3 sep-bottom-lg"><a href="shop-product.html" class="product-image outline-outward"><img src="resources/img/products/8.jpg" alt="Woman's Purse" class="img-responsive"></a> -->
<!--           <div class="product-title"><span class="upper">woman</span> -->
<!--             <p>Woman's Purse</p> -->
<!--           </div> -->
<!--           <div class="product-detail"> -->
<!--             <div class="pull-right price-shop text-right"> -->
<!--               <del>$35.00</del><ins>$30.00</ins> -->
<!--             </div> -->
<!--             <div class="rate"> -->
<!--               <input type="number" name="" value="5" data-clearable="remove" data-max="5" data-min="1" data-icon-lib="fa" data-active-icon="fa-star" data-inactive-icon="fa-star-o" data-clearable-icon="fa-times" class="rating"> -->
<!--             </div><a href="#">24 customer reviews</a> -->
<!--           </div> -->
<!--         </div> -->
<!--         <div class="col-md-3 sep-bottom-lg"><a href="shop-product.html" class="product-image outline-outward"><img src="resources/img/products/3.jpg" alt="Heaven White Shirt" class="img-responsive"><span class="bullet">Sale</span></a> -->
<!--           <div class="product-title"><span class="upper">woman</span> -->
<!--             <p>Heaven White Shirt</p> -->
<!--           </div> -->
<!--           <div class="product-detail"> -->
<!--             <div class="pull-right price-shop text-right"> -->
<!--               <del>$25.00</del><ins>$18.50</ins> -->
<!--             </div> -->
<!--             <div class="rate"> -->
<!--               <input type="number" name="" value="4" data-clearable="remove" data-max="5" data-min="1" data-icon-lib="fa" data-active-icon="fa-star" data-inactive-icon="fa-star-o" data-clearable-icon="fa-times" class="rating"> -->
<!--             </div><a href="#">12 customer reviews</a> -->
<!--           </div> -->
<!--         </div> -->
<!--         <div class="col-md-3 sep-bottom-lg"><a href="shop-product.html" class="product-image outline-outward"><img src="resources/img/products/1.jpg" alt="Sunny Tank Selected Femme" class="img-responsive"><span class="bullet">Sale</span></a> -->
<!--           <div class="product-title"><span class="upper">woman</span> -->
<!--             <p>Sunny Tank Selected Femme</p> -->
<!--           </div> -->
<!--           <div class="product-detail"> -->
<!--             <div class="pull-right price-shop text-right"> -->
<!--               <del>$19.00</del><ins>$15.00</ins> -->
<!--             </div> -->
<!--             <div class="rate"> -->
<!--               <input type="number" name="" value="5" data-clearable="remove" data-max="5" data-min="1" data-icon-lib="fa" data-active-icon="fa-star" data-inactive-icon="fa-star-o" data-clearable-icon="fa-times" class="rating"> -->
<!--             </div><a href="#">3 customer reviews</a> -->
<!--           </div> -->
<!--         </div> -->
<!--         <div class="col-md-3 sep-bottom-lg"><a href="shop-product.html" class="product-image outline-outward"><img src="resources/img/products/5.jpg" alt="Dublin Blue Shirt" class="img-responsive"><span class="bullet out">Out of Stock</span></a> -->
<!--           <div class="product-title"><span class="upper">man</span> -->
<!--             <p>Dublin Blue Shirt</p> -->
<!--           </div> -->
<!--           <div class="product-detail"> -->
<!--             <div class="pull-right price-shop text-right"> -->
<!--               <del>$32.00</del><ins>$30.00</ins> -->
<!--             </div> -->
<!--             <div class="rate"> -->
<!--               <input type="number" name="" value="4" data-clearable="remove" data-max="5" data-min="1" data-icon-lib="fa" data-active-icon="fa-star" data-inactive-icon="fa-star-o" data-clearable-icon="fa-times" class="rating"> -->
<!--             </div><a href="#">18 customer reviews</a> -->
<!--           </div> -->
<!--         </div> -->
<!--         <div class="col-md-3 sep-bottom-lg"><a href="shop-product.html" class="product-image outline-outward"><img src="resources/img/products/7.jpg" alt="Woman's Jeans" class="img-responsive"></a> -->
<!--           <div class="product-title"><span class="upper">woman</span> -->
<!--             <p>Woman's Jeans</p> -->
<!--           </div> -->
<!--           <div class="product-detail"> -->
<!--             <div class="pull-right price-shop text-right"> -->
<!--               <del>$64.00</del><ins>$58.00</ins> -->
<!--             </div> -->
<!--             <div class="rate"> -->
<!--               <input type="number" name="" value="4" data-clearable="remove" data-max="5" data-min="1" data-icon-lib="fa" data-active-icon="fa-star" data-inactive-icon="fa-star-o" data-clearable-icon="fa-times" class="rating"> -->
<!--             </div><a href="#">13 customer reviews</a> -->
<!--           </div> -->
<!--         </div> -->
<!--         <div class="col-md-3 sep-bottom-lg"><a href="shop-product.html" class="product-image outline-outward"><img src="resources/img/products/6.jpg" alt="Robert jacket" class="img-responsive"></a> -->
<!--           <div class="product-title"><span class="upper">man</span> -->
<!--             <p>Robert jacket</p> -->
<!--           </div> -->
<!--           <div class="product-detail"> -->
<!--             <div class="pull-right price-shop text-right"> -->
<!--               <del>$49.00</del><ins>$39.90</ins> -->
<!--             </div> -->
<!--             <div class="rate"> -->
<!--               <input type="number" name="" value="5" data-clearable="remove" data-max="5" data-min="1" data-icon-lib="fa" data-active-icon="fa-star" data-inactive-icon="fa-star-o" data-clearable-icon="fa-times" class="rating"> -->
<!--             </div><a href="#">7 customer reviews</a> -->
<!--           </div> -->
<!--         </div> -->
      </div>
    </div>
</section>
<footer id="footer">
    <div class="copyright sep-top-xs sep-bottom-xs">
      <div class="container">
        <div class="row">
          <div class="col-md-12"><small>Copyright 2016 © Ocharos tour. All rights reserved.</small></div>
        </div>
      </div>
    </div>
</footer>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">ยืนยัน</h4>
            </div>

            <div class="modal-body">
                <p>กรุณายืนยันการทำรายการ</p>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
                <a class="btn btn-danger btn-ok" id="confirm-delete-btn">ยืนยัน</a>
            </div>
        </div>
    </div>
</div>
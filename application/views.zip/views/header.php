<section class="header-section fading-title parallax">
        <div class="section-shade sep-top-5x sep-bottom-2x">
          <div class="container">
          	<div style="background-image: url(resources/img/intro.png);" class="sl-slide-inner"></div>
          </div>
        </div>
      </section>